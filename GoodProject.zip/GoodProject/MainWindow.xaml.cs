﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Collections.ObjectModel;

namespace GoodProject
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {


        //DBEntities //DBModel
        public static database.DBEntities connection = new database.DBEntities();

        public ObservableCollection<database.Materials> Material { get; set; } = new ObservableCollection<database.Materials>();

        public ObservableCollection<SortList> FillSort { get; set; } = new ObservableCollection<SortList>
        {
            new SortList() { NameS = "Сбросить сортировку", Description=null, ascending=true},
            new SortList() { NameS = "Сортировка по имени(возр.)", Description="Наименование_материала", ascending=true},
            new SortList() { NameS = "Сортировка по имени(уб.)", Description="Наименование_материала", ascending=false},
            new SortList() { NameS = "Сортировка по кол-ву на складе (возр.)", Description="Количество_на_складе", ascending=true},
            new SortList() { NameS = "Сортировка по кол-ву на складе (уб.)", Description="Количество_на_складе", ascending=false},
            new SortList() { NameS = "Сортировка по цене (возр.)", Description="Цена", ascending=true},
            new SortList() { NameS = "Сортировка по цене (уб.)", Description="Цена", ascending=false}
        };
        public ObservableCollection<database.MatType> MatType { get; set; } =new ObservableCollection<database.MatType>();
        

        public MainWindow()
        {
            InitializeComponent();
            connection.Materials.ToList().ForEach(material => Material.Add(material));
            MatType.Add(new database.MatType() { Тип_материала = "Все типы" });
            connection.MatType.ToList().ForEach(m => { MatType.Add(m); });
            DataContext = this;
        }

        private void Sorting_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            SortList a = Sorting.SelectedItem as SortList;
            Sort(a.Description, a.ascending);
        }

        public void Sort(string Description, bool Asc)
        {
            ICollectionView view = CollectionViewSource.GetDefaultView(ListBoxMat.ItemsSource);
            if (view == null)
                return;
            view.SortDescriptions.Clear();
            if (Description != null)
            {
                view.SortDescriptions.Add(new SortDescription(Description, Asc ? ListSortDirection.Ascending : ListSortDirection.Descending));
            }
        }

        public void Filter(string a) 
        {
            ICollectionView view = CollectionViewSource.GetDefaultView(ListBoxMat.ItemsSource);
            if (view == null)
                return;
           view.Filter()= Predicate<object>(obj =>
           {
               if(a=="Все типы") return true;


           });
        }

        private void Filtrating_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            string a = Filtrating.SelectedValuePath as string;
            Filter(a);
        }
    }

    public class SortList
    {
        public string NameS { get; set; } 
        public string Description { get; set; }
        public bool ascending { get; set; }
    }
}
