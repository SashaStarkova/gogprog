﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GoodProject
{
    /// <summary>
    /// Логика взаимодействия для CreateMaterial.xaml
    /// </summary>
    public partial class CreateMaterial : Window
    {
        public database.Materials Material { get; set; }
        public CreateMaterial()
        {
            InitializeComponent();
            
            MATYPE.SetBinding(ComboBox.ItemsSourceProperty, new Binding()
            {
                Source = MainWindow.MatType
            });
            MAUNIT.SetBinding(ComboBox.ItemsSourceProperty, new Binding()
            {
                Source = MainWindow.Unit
            });
            DataContext = this;
        }

        private void SaveMat(object sender, RoutedEventArgs e)
        {
            MainWindow.connection.Materials.Add(Material);
            if(MainWindow.connection.SaveChanges()==1) 
            {
                MainWindow.Material.Add(Material);
                Material = new database.Materials();
                SpMat.GetBindingExpression(DataContextProperty).UpdateTarget;
            }
        }
    }
}
