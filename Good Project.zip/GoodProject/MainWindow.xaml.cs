﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Collections.ObjectModel;

namespace GoodProject
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {


        //DBEntities //DBModel
        public static database.DBEntities connection = new database.DBEntities();

        public static ObservableCollection<database.Materials> Material { get; set; } = new ObservableCollection<database.Materials>();

        public  ObservableCollection<SortList> FillSort { get; set; } = new ObservableCollection<SortList>
        {
            new SortList() { NameS = "Сбросить сортировку", Description=null, ascending=true},
            new SortList() { NameS = "Сортировка по имени(возр.)", Description="Наименование_материала", ascending=true},
            new SortList() { NameS = "Сортировка по имени(уб.)", Description="Наименование_материала", ascending=false},
            new SortList() { NameS = "Сортировка по кол-ву на складе (возр.)", Description="Количество_на_складе", ascending=true},
            new SortList() { NameS = "Сортировка по кол-ву на складе (уб.)", Description="Количество_на_складе", ascending=false},
            new SortList() { NameS = "Сортировка по цене (возр.)", Description="Цена", ascending=true},
            new SortList() { NameS = "Сортировка по цене (уб.)", Description="Цена", ascending=false}
        };
        public static ObservableCollection<database.MatType> MatType { get; set; } =new ObservableCollection<database.MatType>();
        public static ObservableCollection<database.Unit> Unit { get; set; } = new ObservableCollection<database.Unit>();
        EditMaterial editmaterial = null;
        CreateMaterial createMaterial = null;

        public MainWindow()
        {
            InitializeComponent();
            connection.Materials.ToList().ForEach(material => Material.Add(material));
            MatType.Add(new database.MatType() { Тип_материала = "Все типы" });
            connection.MatType.ToList().ForEach(m => { MatType.Add(m); });
            TotalMat.Text=Material.Count.ToString();
            DataContext = this;
            connection.Unit.ToList().ForEach(m => { Unit.Add(m); });
        }


        private void Sorting_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            SortList a = Sorting.SelectedItem as SortList;
            Sort(a.Description, a.ascending);
        }

        public void Sort(string Description, bool Asc)
        {
            ICollectionView view = CollectionViewSource.GetDefaultView(ListBoxMat.ItemsSource);
            if (view == null)
                return;
            view.SortDescriptions.Clear();
            if (Description != null)
            {
                view.SortDescriptions.Add(new SortDescription(Description, Asc ? ListSortDirection.Ascending : ListSortDirection.Descending));
            }
        }

        public void Filter(database.MatType a) 
        {
            ICollectionView view = CollectionViewSource.GetDefaultView(ListBoxMat.ItemsSource);
            if (view == null)
                return;
            int counter = 0;
            view.Filter = new Predicate<object>(obj =>
              {
              if (a.Тип_материала == "Все типы") return true;
                  bool isView = ((database.Materials)obj).MatType == a;
                  if (isView) counter++;
                  return isView;
              });
            ViewMat.Text = counter.ToString();

        }

        private void Filtrating_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            database.MatType a = Filtrating.SelectedItem as database.MatType;
            Filter(a);

        }

        private void TBTextChanged(object sender, TextChangedEventArgs e)
        {
            SearchFilter(Search.Text);
        }
        public void SearchFilter(string b)
        {
            ICollectionView view = CollectionViewSource.GetDefaultView(ListBoxMat.ItemsSource);
            int counter = 0;
            if (view == null)
                return;
            view.Filter = new Predicate<object>(obj =>
            {
                bool isView= ((database.Materials)obj).Наименование_материала.ToLower().Contains(b.ToLower());
                if (isView) counter++;
                return isView;
            }
            );
            ViewMat.Text=counter.ToString();

        }
        public void LBselection_changed(object sender, SelectionChangedEventArgs e)
        {
            if (editmaterial != null) return;
            editmaterial = new EditMaterial(ListBoxMat.SelectedItem as database.Materials);
            editmaterial.Closed += EditMaterial_Closed;
            editmaterial.Show();
        }
        private void EditMaterial_Closed(object sender,EventArgs e)
        {
            editmaterial = null;
        }

        private void AddMat(object sender, RoutedEventArgs e)
        {
            if (createMaterial != null) return;
            createMaterial = new CreateMaterial();
            createMaterial.Closed += CreateMaterial_Closed;
            createMaterial.Show();
        }
        private void CreateMaterial_Closed(object sender, EventArgs e)
        {
            createMaterial = null;
        }


    }


    public class SortList
    {
        public string NameS { get; set; } 
        public string Description { get; set; }
        public bool ascending { get; set; }
    }
}
