﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GoodProject
{
    /// <summary>
    /// Логика взаимодействия для EditMaterial.xaml
    /// </summary>
    public partial class EditMaterial : Window
    {

        public database.Materials Material { get; set; }
        public EditMaterial(database.Materials materials)
        {
            InitializeComponent();
            Material = materials;
            MATYPE.SetBinding(ComboBox.ItemsSourceProperty, new Binding()
            {   
                Source=MainWindow.MatType
            });
            MAUNIT.SetBinding(ComboBox.ItemsSourceProperty, new Binding()
            {
                Source = MainWindow.Unit
            });
            DataContext = this;

        }

        private void SaveMat(object sender, RoutedEventArgs e)
        {
            
            MainWindow.connection.SaveChanges();
        }

        private void DelMat(object sender, RoutedEventArgs e)
        {

        }
    }
}
